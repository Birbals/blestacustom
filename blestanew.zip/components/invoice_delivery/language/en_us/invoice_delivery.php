<?php
// Errors
$lang['InvoiceDelivery.!error.libxml_required'] = 'The libxml and simplexml extensions are required for invoice delivery.';

$lang['InvoiceDelivery.deliverinvoices.interfax_subject'] = 'Invoice #%1$s'; // %1$s is the invoice number (or the first invoice number in a group of several)
$lang['InvoiceDelivery.deliverinvoices.postalmethods_description'] = 'Invoice #%1$s'; // %1$s is the invoice number (or the first invoice number in a group of several);
