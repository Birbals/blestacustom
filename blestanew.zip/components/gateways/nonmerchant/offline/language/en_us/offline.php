<?php
$lang['Offline.name'] = 'Offline Payment';
$lang['Offline.instructions'] = 'Instructions';

// Errors
$lang['Offline.!error.instructions.valid'] = 'You must enter some instructions.';
