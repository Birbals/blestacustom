<?php

final class Braintree_MerchantAccount_FundingDetails extends Braintree_Instance
{
    protected $_attributes = array();
}
